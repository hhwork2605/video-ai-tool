import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import '@/index.css';
import { SettingsPage } from './SettingsPage';

const container = document.getElementById('root');
if (!container) {
  throw new Error('Root element not found in settings.html');
}

createRoot(container).render(
  <StrictMode>
    <SettingsPage />
  </StrictMode>,
);
